var server_table;
var server_row_index = 0;

function preload() {
  set_global_colors();
  console.log("preload");
  server_table = load_table("data1"); 
  // no code here; the table is loaded async
}

clusters = {}; // clusters[cluster_name] = {hsm_name: ]
servers = {};  // servers[cluster_name] = [hsm_name,hsm_name,hsm_name] 

function setup() {
  console.log("setup")
  frameRate(60);
  createCanvas(900,600); // w,h
}

const movement_speed = 10; 

r = 150
x0 = 200
y0 = 250

zones= []
hsms = []
servers = []
clusters = []

function draw() {
  if( frameCount%10 == 0 ) console.log("draw", frameCount);

  process_server_file(frameCount)

  background(100); // clears canvas

  push(); // save draw state

  // big outside circle
  stroke(WHITE); noFill();
  circle(x0, y0, r+150);
  // small inner circle
  stroke(RED); noFill();
  circle(x0, y0, 30);

  draw_zone_ring([HALF_PI,HALF_PI,PI], x0, y0, r+30, 3);
  draw_zone_ring([PI,HALF_PI,HALF_PI], x0, y0, r, 3);

  // temp: where to place the hsms on the ring
  let angles = [30, 10, 45, 35, 60, 38, 75, 67];

  r = 100

  const draw_dot_on_ring = (theta, color) => {
    x = x0 + r * cos(theta)
    y = y0 + r * sin(theta)
    stroke(color); noFill();
    circle(x, y, 10);
  }

  clusters.forEach((c)=>{
    c.hsms.forEach((h,i)=>{
      const alpha = angles[i]
      draw_dot_on_ring(alpha,RED)
      stroke(126);
      c.hsms.forEach((hh,j)=>{
        beta = angles[j]
        p1 = loc(alpha, x0, y0, r)
        p2 = loc(beta, x0, y0, r)
        line(p1[0], p1[1], p2[0], p2[1]);
      })
    })
  })
  

  // print HSM names on the diagram
  stroke(BLACK); fill(BLACK);
  const t_left = 400
  var t_top = 150 
  clusters.forEach((c,i)=>{
    text(c.name, t_left, t_top);
    t_top += 15;
    c.hsms.forEach((h,j)=>{
      text(h.name, t_left+5, t_top);
      t_top += 15;
    });
  });


  pop(); // restore draw state

  if( frameCount > 600 ){
    hsms.forEach(h=>console.log(h.name, h));
    zones.forEach(z=>console.log(z.name, z));
    servers.forEach(s=>console.log(s.name, s));
    clusters.forEach(c=>console.log(c.name, c));
    noLoop(); // stop after a number of iterations
  }
}

const loc = (a, x0, y0, r ) => {
  // x y coordinates of point on circle
  return [x0 + r * cos(a),y0 + r * sin(a)];
}

function draw_zone_ring(zones, x, y, radius) {
  strokeWeight(10); //thick
  const count = zones.length;
  var start = 0;
  for (let i = 0; i < count; i++) {
    let gray = map(i, 0, count, 0, 255);
    var final = start+zones[i];
    draw_arc(x,y,2*radius,start, final, gray)
    start = final;
  }
  strokeWeight(1);
}

const draw_arc = (x,y,radius,start,stop,color) =>{
  stroke(color); noFill();
  arc( x, y, radius, radius, start, stop);
}

TIME_COLUMN_INDEX = 0
ACTION_COLUMN_INDEX = 1
NAME_COLUMN_INDEX = 2

ADD_DROPLET = "add_droplet"
DELETE_HSM = "del_hsm"
ADD_ZONE = "add_zone"
ADD_HSM = "add_hsm"

class Actions {
  add_zone(table, index){
    // 10, add_zone, IAD6
    const args = parse_line(table, index, 1)
    console.log("add zone: ", args[0])
    get_or_create(zones,new Zone(...args))
  }
  add_droplet(table, index){
    // 50, add_droplet, 1.1.1.1, IAD6, blue
    const args = parse_line(table, index, 3)
    console.log("add droplet: ", args[0]);
    get_or_create(servers,new Server(...args))
  }
  add_hsm(table, index){
    // 200, add_hsm, mary, 1.1.1.33, cluster1, blue
    const args = parse_line(table, index, 4);
    const [hsm_name, server_name, cluster_name, hsm_color] = args;
    console.log("add hsm: ", hsm_name, "to", cluster_name);
    const hsm = get_or_create(hsms,new Hsm(...args));
    const cluster = get_or_create(clusters,new Cluster(cluster_name))
    cluster.add_hsm(hsm)
    const server = get_or_create(servers,new Server(server_name));
    server.add_hsm(hsm)
  }
  del_hsm(table, index){
    // 500, del_hsm, pat2
    const args = parse_line(table, index, 1);
    const hsm_name = args[0];
    const i = hsms.findIndex(x => x.name == hsm_name);
    console.log("del hsm: ", hsm_name, i);
    clusters.forEach(s=>{delete s.hsms[hsm_name]});
    servers.forEach(s=>{delete s.hsms[hsm_name]});
    hsms.splice(i,1);
  } 
}
actions = new Actions();

const parse_line = (table, index, count) => {
  // 0 is time
  // 1 is action
  results = []
  for( var i=2; i<2+count; i++){
    results.push(trim(table.getString(index,i)));
  } 
  return results;
}

const process_server_file = (timeCounter) => {
  // read all the unread rows for time less or equal now
  while( next_row_time(server_table) <= timeCounter ){
    server_row_index += 1
    const action = trim(server_table.getString(server_row_index,ACTION_COLUMN_INDEX));
    // if( action == ADD_HSM ) actions[action](server_table,server_row_index)
    // if( action == ADD_ZONE ) actions[action](server_table,server_row_index)
    // if( action == ADD_DROPLET ) actions[action](server_table,server_row_index)
    actions[action](server_table,server_row_index)
  }
}

const get_or_create = (xs,n) => {
  e = xs.find(x => n.name == x.name);
  console.log("found",e);
  if( e ) return e;
  xs.push(n);
  return n;
}

const next_row_time = (table) => {
  // all our tables have
  const data_row_count = server_table.getRowCount()-1; // less header
  if( server_row_index >= data_row_count ) return 9999999999; // max time
  // otherwise return the time on the next row to be read
  return trim(server_table.getString(server_row_index+1,TIME_COLUMN_INDEX));
}

const load_table = (filename) => {
  const table =  loadTable("assets/"+filename+".csv", "csv", function () {
      var row_count = table.getRowCount();
      var col_count = table.getColumnCount();
      console.log(filename, "table loaded", row_count, col_count);
  });
  return table
};
